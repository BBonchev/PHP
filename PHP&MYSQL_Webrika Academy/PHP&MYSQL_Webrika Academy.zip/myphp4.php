<?php

function sayHello() {
    echo 'Hello world' . '<br>';
}

sayHello();
function presstoopen () {
    echo 'You pressed' . '<br>';
}

presstoopen ();

function obhod () {
    echo 'obhod na masiv';
}

obhod ();